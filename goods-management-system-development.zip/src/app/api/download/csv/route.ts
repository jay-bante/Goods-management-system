import { NextResponse } from "next/server";
import fs from "fs/promises";
import { CSV_FILE } from "@/lib/inventory";

export async function GET() {
  try {
    const file = await fs.readFile(CSV_FILE);
    return new NextResponse(file, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": "attachment; filename=inventory.csv",
      },
    });
  } catch {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }
}
