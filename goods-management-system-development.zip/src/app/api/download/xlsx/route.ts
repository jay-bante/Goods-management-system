import { NextResponse } from "next/server";
import fs from "fs/promises";
import { XLSX_FILE } from "@/lib/inventory";

export async function GET() {
  try {
    const file = await fs.readFile(XLSX_FILE);
    return new NextResponse(file, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": "attachment; filename=inventory.xlsx",
      },
    });
  } catch {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }
}
