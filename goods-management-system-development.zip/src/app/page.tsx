import InventoryManager from "@/components/InventoryManager";
import { readEntries } from "@/lib/fileStore";

export default async function HomePage() {
  const entries = await readEntries();
  return <InventoryManager initialEntries={entries} />;
}
