"use server";

import { InventoryEntry } from "./inventory";
import { addEntry, deleteEntry, readEntries, updateEntry } from "./fileStore";

export async function getEntriesAction(): Promise<InventoryEntry[]> {
  return readEntries();
}

export async function addEntryAction(entry: InventoryEntry) {
  await addEntry(entry);
}

export async function updateEntryAction(entry: InventoryEntry) {
  await updateEntry(entry);
}

export async function deleteEntryAction(id: string) {
  await deleteEntry(id);
}
