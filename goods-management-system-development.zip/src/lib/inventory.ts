export type InventoryEntry = {
  id: string;
  date: string; // YYYY-MM-DD
  itemName: string;
  arrived: number;
  sold: number;
  costPrice: number;
  sellingPrice: number;
};

export type ComputedEntry = InventoryEntry & {
  stock: number;
  profit: number;
  revenue: number;
};

export const DATA_DIR = "./data";
export const CSV_FILE = `${DATA_DIR}/inventory.csv`;
export const XLSX_FILE = `${DATA_DIR}/inventory.xlsx`;

export function computeEntry(entry: InventoryEntry): ComputedEntry {
  const stock = Math.max(0, entry.arrived - entry.sold);
  const profit = (entry.sellingPrice - entry.costPrice) * entry.sold;
  const revenue = entry.sellingPrice * entry.sold;
  return { ...entry, stock, profit, revenue };
}

export function sortEntries(
  entries: InventoryEntry[],
  key: keyof ComputedEntry | keyof InventoryEntry,
  direction: "asc" | "desc"
): InventoryEntry[] {
  return [...entries].sort((a, b) => {
    const ca = computeEntry(a);
    const cb = computeEntry(b);
    const va = ca[key as keyof ComputedEntry];
    const vb = cb[key as keyof ComputedEntry];
    if (typeof va === "number" && typeof vb === "number") {
      return direction === "asc" ? va - vb : vb - va;
    }
    const sa = String(va);
    const sb = String(vb);
    return direction === "asc" ? sa.localeCompare(sb) : sb.localeCompare(sa);
  });
}
