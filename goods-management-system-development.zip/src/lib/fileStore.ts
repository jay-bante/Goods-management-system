"use server";

import fs from "fs/promises";
import path from "path";
import * as xlsx from "xlsx";
import {
  CSV_FILE,
  DATA_DIR,
  InventoryEntry,
  XLSX_FILE,
} from "./inventory";

const HEADERS: (keyof InventoryEntry)[] = [
  "id",
  "date",
  "itemName",
  "arrived",
  "sold",
  "costPrice",
  "sellingPrice",
];

export async function ensureDataDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

export async function readEntries(): Promise<InventoryEntry[]> {
  await ensureDataDir();
  try {
    await fs.access(XLSX_FILE);
    const buf = await fs.readFile(XLSX_FILE);
    const wb = xlsx.read(buf, { type: "buffer" });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = xlsx.utils.sheet_to_json<Record<string, unknown>>(ws);
    return rows
      .map((row): InventoryEntry | null => {
        if (!row["id"] || !row["itemName"]) return null;
        return {
          id: String(row["id"]),
          date: String(row["date"] || new Date().toISOString().slice(0, 10)),
          itemName: String(row["itemName"]),
          arrived: Number(row["arrived"] || 0),
          sold: Number(row["sold"] || 0),
          costPrice: Number(row["costPrice"] || 0),
          sellingPrice: Number(row["sellingPrice"] || 0),
        };
      })
      .filter((e): e is InventoryEntry => e !== null);
  } catch {
    return [];
  }
}

export async function writeEntries(entries: InventoryEntry[]) {
  await ensureDataDir();

  // CSV
  const csvRows = [HEADERS.join(",")];
  for (const e of entries) {
    csvRows.push(
      HEADERS.map((h) => `"${String(e[h]).replace(/"/g, "\"\"")}"`).join(",")
    );
  }
  await fs.writeFile(CSV_FILE, csvRows.join("\n"), "utf-8");

  // XLSX
  const ws = xlsx.utils.json_to_sheet(entries, { header: HEADERS });
  const wb = xlsx.utils.book_new();
  xlsx.utils.book_append_sheet(wb, ws, "Inventory");
  const buf = xlsx.write(wb, { type: "buffer", bookType: "xlsx" });
  await fs.writeFile(XLSX_FILE, Buffer.from(buf));
}

export async function addEntry(entry: InventoryEntry) {
  const entries = await readEntries();
  entries.push(entry);
  await writeEntries(entries);
}

export async function updateEntry(updated: InventoryEntry) {
  const entries = await readEntries();
  const idx = entries.findIndex((e) => e.id === updated.id);
  if (idx === -1) throw new Error("Entry not found");
  entries[idx] = updated;
  await writeEntries(entries);
}

export async function deleteEntry(id: string) {
  const entries = await readEntries();
  const filtered = entries.filter((e) => e.id !== id);
  await writeEntries(filtered);
}
