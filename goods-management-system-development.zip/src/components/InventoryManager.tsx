"use client";

import { useMemo, useState } from "react";
import {
  addEntryAction,
  deleteEntryAction,
  updateEntryAction,
} from "@/lib/actions";
import {
  computeEntry,
  ComputedEntry,
  InventoryEntry,
  sortEntries,
} from "@/lib/inventory";

type Tab = "manage" | "view";

type SortState = {
  key: keyof ComputedEntry | keyof InventoryEntry;
  direction: "asc" | "desc";
};

export default function InventoryManager({
  initialEntries,
}: {
  initialEntries: InventoryEntry[];
}) {
  const [entries, setEntries] = useState<InventoryEntry[]>(initialEntries);
  const [tab, setTab] = useState<Tab>("manage");
  const [editing, setEditing] = useState<InventoryEntry | null>(null);
  const [sort, setSort] = useState<SortState>({ key: "date", direction: "desc" });
  const [dateFilter, setDateFilter] = useState("");

  const [form, setForm] = useState<Omit<InventoryEntry, "id">>({
    date: new Date().toISOString().slice(0, 10),
    itemName: "",
    arrived: 0,
    sold: 0,
    costPrice: 0,
    sellingPrice: 0,
  });

  const totals = useMemo(() => {
    const computed = entries.map(computeEntry);
    const totalArrived = computed.reduce((s, e) => s + e.arrived, 0);
    const totalSold = computed.reduce((s, e) => s + e.sold, 0);
    const totalProfit = computed.reduce((s, e) => s + e.profit, 0);
    const totalRevenue = computed.reduce((s, e) => s + e.revenue, 0);
    return { totalArrived, totalSold, totalProfit, totalRevenue };
  }, [entries]);

  const displayedEntries = useMemo(() => {
    let data = sortEntries(entries, sort.key, sort.direction);
    if (dateFilter) {
      data = data.filter((e) => e.date === dateFilter);
    }
    return data;
  }, [entries, sort, dateFilter]);

  function resetForm() {
    setForm({
      date: new Date().toISOString().slice(0, 10),
      itemName: "",
      arrived: 0,
      sold: 0,
      costPrice: 0,
      sellingPrice: 0,
    });
    setEditing(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const entry: InventoryEntry = editing
      ? { ...form, id: editing.id }
      : { ...form, id: crypto.randomUUID() };

    if (editing) {
      await updateEntryAction(entry);
    } else {
      await addEntryAction(entry);
    }
    const updated = editing
      ? entries.map((en) => (en.id === entry.id ? entry : en))
      : [...entries, entry];
    setEntries(updated);
    resetForm();
  }

  function handleEdit(entry: InventoryEntry) {
    setEditing(entry);
    setForm({
      date: entry.date,
      itemName: entry.itemName,
      arrived: entry.arrived,
      sold: entry.sold,
      costPrice: entry.costPrice,
      sellingPrice: entry.sellingPrice,
    });
    setTab("manage");
  }

  async function handleDelete(id: string) {
    if (!confirm("Are you sure you want to delete this entry?")) return;
    await deleteEntryAction(id);
    setEntries(entries.filter((e) => e.id !== id));
  }

  function toggleSort(key: keyof ComputedEntry | keyof InventoryEntry) {
    setSort((prev) => ({
      key,
      direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
    }));
  }

  const inputClass =
    "w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";

  return (
    <div className="mx-auto max-w-6xl p-4 md:p-6">
      <header className="mb-6 text-center">
        <h1 className="text-3xl font-bold text-gray-900">Goods Management System</h1>
        <p className="mt-1 text-gray-600">
          Manage inventory entries. Data is saved permanently to CSV/Excel files.
        </p>
      </header>

      <div className="mb-6 flex items-center justify-center gap-4">
        <button
          onClick={() => setTab("manage")}
          className={`rounded-full px-6 py-2 font-medium transition ${
            tab === "manage"
              ? "bg-blue-600 text-white shadow"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          Manage Data
        </button>
        <button
          onClick={() => setTab("view")}
          className={`rounded-full px-6 py-2 font-medium transition ${
            tab === "view"
              ? "bg-blue-600 text-white shadow"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          View Data
        </button>
      </div>

      {tab === "manage" ? (
        <section className="rounded-xl border bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-xl font-semibold text-gray-800">
            {editing ? "Edit Entry" : "Add New Entry"}
          </h2>
          <form onSubmit={handleSubmit} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Date</label>
              <input
                type="date"
                required
                className={inputClass}
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Item Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Rice"
                className={inputClass}
                value={form.itemName}
                onChange={(e) => setForm({ ...form, itemName: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Arrived Qty</label>
              <input
                type="number"
                min={0}
                required
                className={inputClass}
                value={form.arrived}
                onChange={(e) =>
                  setForm({ ...form, arrived: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Sold Qty</label>
              <input
                type="number"
                min={0}
                required
                className={inputClass}
                value={form.sold}
                onChange={(e) =>
                  setForm({ ...form, sold: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Cost Price</label>
              <input
                type="number"
                min={0}
                step="0.01"
                required
                className={inputClass}
                value={form.costPrice}
                onChange={(e) =>
                  setForm({ ...form, costPrice: Number(e.target.value) })
                }
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Selling Price</label>
              <input
                type="number"
                min={0}
                step="0.01"
                required
                className={inputClass}
                value={form.sellingPrice}
                onChange={(e) =>
                  setForm({ ...form, sellingPrice: Number(e.target.value) })
                }
              />
            </div>
            <div className="flex items-end gap-2 sm:col-span-2 lg:col-span-3">
              <button
                type="submit"
                className="rounded-md bg-blue-600 px-5 py-2.5 font-medium text-white hover:bg-blue-700"
              >
                {editing ? "Update Entry" : "Add Entry"}
              </button>
              {editing && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="rounded-md bg-gray-200 px-5 py-2.5 font-medium text-gray-800 hover:bg-gray-300"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="/api/download/csv"
              className="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700"
            >
              Download CSV
            </a>
            <a
              href="/api/download/xlsx"
              className="rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700"
            >
              Download Excel
            </a>
          </div>

          <div className="mt-8">
            <h3 className="mb-3 text-lg font-semibold text-gray-800">Quick Actions</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full text-left text-sm">
                <thead className="bg-gray-50 text-gray-700">
                  <tr>
                    <th className="px-4 py-2">Date</th>
                    <th className="px-4 py-2">Item</th>
                    <th className="px-4 py-2">Arrived</th>
                    <th className="px-4 py-2">Sold</th>
                    <th className="px-4 py-2">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {entries.slice(-5).reverse().map((entry) => (
                    <tr key={entry.id} className="hover:bg-gray-50">
                      <td className="px-4 py-2">{entry.date}</td>
                      <td className="px-4 py-2">{entry.itemName}</td>
                      <td className="px-4 py-2">{entry.arrived}</td>
                      <td className="px-4 py-2">{entry.sold}</td>
                      <td className="px-4 py-2">
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(entry)}
                            className="rounded bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-200"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(entry.id)}
                            className="rounded bg-red-100 px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-200"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {entries.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-4 py-4 text-center text-gray-500">
                        No entries yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      ) : (
        <section className="rounded-xl border bg-white p-6 shadow-sm">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
            <h2 className="text-xl font-semibold text-gray-800">Inventory Records</h2>
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-gray-700">Filter by date:</label>
              <input
                type="date"
                className={inputClass}
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
              />
              {dateFilter && (
                <button
                  onClick={() => setDateFilter("")}
                  className="rounded-md bg-gray-200 px-3 py-2 text-sm text-gray-700 hover:bg-gray-300"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <SummaryCard label="Total Arrived" value={totals.totalArrived} />
            <SummaryCard label="Total Sold" value={totals.totalSold} />
            <SummaryCard label="Total Revenue" value={totals.totalRevenue} prefix="$" />
            <SummaryCard label="Total Profit" value={totals.totalProfit} prefix="$" />
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-gray-50 text-gray-700">
                <tr>
                  <SortHeader label="Date" sortKey="date" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Item" sortKey="itemName" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Arrived" sortKey="arrived" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Sold" sortKey="sold" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Stock" sortKey="stock" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Cost" sortKey="costPrice" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Selling" sortKey="sellingPrice" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Revenue" sortKey="revenue" sort={sort} onClick={toggleSort} />
                  <SortHeader label="Profit" sortKey="profit" sort={sort} onClick={toggleSort} />
                  <th className="px-4 py-2">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {displayedEntries.map((entry) => {
                  const c = computeEntry(entry);
                  return (
                    <tr key={entry.id} className="hover:bg-gray-50">
                      <td className="px-4 py-2 whitespace-nowrap">{entry.date}</td>
                      <td className="px-4 py-2">{entry.itemName}</td>
                      <td className="px-4 py-2">{entry.arrived}</td>
                      <td className="px-4 py-2">{entry.sold}</td>
                      <td className="px-4 py-2">{c.stock}</td>
                      <td className="px-4 py-2">${entry.costPrice.toFixed(2)}</td>
                      <td className="px-4 py-2">${entry.sellingPrice.toFixed(2)}</td>
                      <td className="px-4 py-2">${c.revenue.toFixed(2)}</td>
                      <td className="px-4 py-2 font-medium text-green-700">
                        ${c.profit.toFixed(2)}
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEdit(entry)}
                            className="rounded bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-200"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(entry.id)}
                            className="rounded bg-red-100 px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-200"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {displayedEntries.length === 0 && (
                  <tr>
                    <td colSpan={10} className="px-4 py-6 text-center text-gray-500">
                      No records found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

function SummaryCard({
  label,
  value,
  prefix = "",
}: {
  label: string;
  value: number;
  prefix?: string;
}) {
  return (
    <div className="rounded-lg border bg-gray-50 p-4">
      <p className="text-xs font-medium text-gray-500">{label}</p>
      <p className="mt-1 text-2xl font-bold text-gray-900">
        {prefix}
        {Number.isInteger(value) ? value : value.toFixed(2)}
      </p>
    </div>
  );
}

function SortHeader({
  label,
  sortKey,
  sort,
  onClick,
}: {
  label: string;
  sortKey: keyof ComputedEntry | keyof InventoryEntry;
  sort: SortState;
  onClick: (key: keyof ComputedEntry | keyof InventoryEntry) => void;
}) {
  const active = sort.key === sortKey;
  return (
    <th
      className="cursor-pointer px-4 py-2 select-none hover:bg-gray-100"
      onClick={() => onClick(sortKey)}
    >
      <span className="flex items-center gap-1">
        {label}
        {active && <span>{sort.direction === "asc" ? "▲" : "▼"}</span>}
      </span>
    </th>
  );
}
